
-- --------------------------------------------------------

--
-- Структура таблицы `feedback_store`
--

CREATE TABLE `feedback_store` (
  `id` int(3) NOT NULL,
  `ip` varchar(16) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `doc_name` varchar(25) NOT NULL,
  `href` varchar(15) NOT NULL,
  `ankid` int(3) NOT NULL,
  `answers` varchar(155) NOT NULL,
  `userdata` varchar(555) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
